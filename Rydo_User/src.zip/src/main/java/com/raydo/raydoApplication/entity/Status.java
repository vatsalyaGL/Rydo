package com.raydo.raydoApplication.entity;

public enum Status {
    ACTIVE,
    SUSPENDED,
    PENDING_VERIFICATION,
    DELETED
}
